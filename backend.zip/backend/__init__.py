# Initialize GPT Summarizer package
